function  recognize(){
	var input1=document.getElementsByClassName("QR");
	var input2=document.getElementsByClassName("tdqr");
	
	var canvas = document.createElement('canvas');
	var context = canvas.getContext('2d');
	for(var i=0; i<input1.length; i++)
	{
		var search=input1[i];
//		alert("Tadam!"+search.src);
		search.crossOrigin = "Anonymous";
		var idata=getwithTCanvas(search,canvas,context);
		input2[i].innerHTML=idata.height+","+idata.width;
		input2[i].innerHTML=idata.data;
		var code = jsQR(idata.data, 200,200);

		if (code) {
			console.log("Found QR code", code);
			input2[i].innerHTML=code.data;
		//document.getElementsByClassName("tdqr")[i].innerHTML="1";
		}

		//
	
/*	alert(input1.value);*/
	}
}
	
function getBase64Image(img) {
    // Create an empty canvas element
    var canvas = document.createElement("canvas");
    img.setAttribute('crossOrigin', 'anonymous');
    canvas.width = img.width;
    canvas.height = img.height;

    // Copy the image contents to the canvas
    var ctx = canvas.getContext("2d");
    ctx.drawImage(img, 0, 0);

    // Get the data-URL formatted image
    // Firefox supports PNG and JPEG. You could check img.src to
    // guess the original format, but be aware the using "image/jpg"
    // will re-encode the image.
    var dataURL = canvas.toDataURL("image/png");

    return dataURL.replace(/^data:image\/(png|jpg);base64,/, "");
}

function getBase64FromImageUrl(url) {
    var img = new Image();

    img.setAttribute('crossOrigin', 'anonymous');

    img.onload = function () {
        var canvas = document.createElement("canvas");
        canvas.width =this.width;
        canvas.height =this.height;

        var ctx = canvas.getContext("2d");
        ctx.drawImage(this, 0, 0);

        var dataURL = canvas.toDataURL("image/png");

        return dataURL.replace(/^data:image\/(png|jpg);base64,/, "");
    };

    img.src = url;
}

function toDataURL(url) {
  return fetch(url)
      .then((response)=> {
        return response.blob();
      })
      .then(blob=> {
        return URL.createObjectURL(blob);
      });
}

function getwithTCanvas(img,canvas,context)
{
	
	img.crossOrigin = "Anonymous";
//var img = document.getElementById('myimg');
canvas.width = img.width;
canvas.height = img.height;
context.drawImage(img, 0, 0 );
return context.getImageData(0, 0, img.width, img.height);
}